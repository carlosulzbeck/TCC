/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcc;

/**
 *
 * @author Danilo
 */
class Materia {
    private final String disciplina;
    private final String req;
    private final String ementa;
    private String url;

    public Materia(String disciplina, String req, String ementa) {
        this.disciplina = disciplina;
        this.req = req;
        this.ementa = ementa;
    }
    
    public String getDisciplina() {
        return disciplina;
    }
    
    public String getReq() {
        return req;
    }
    
    public String getEmenta() {
        return ementa;
    }

    public String getUrl() {
        return url;
    }
    
    public void setUrl(String url) {
        this.url = url;
    }
    
    @Override
    public String toString() {
        return "{" + disciplina + ": " + req + " / " + ementa + '}';
    }
    
    
}
