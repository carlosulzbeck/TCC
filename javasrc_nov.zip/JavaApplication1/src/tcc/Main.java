/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcc;

/**
 *
 * @author Danilo
 */
public class Main {

    public static void main(String[] args) {
        String curso = "94";
        String anoCatalogo = "2018";
        if (args.length > 0) {
            curso = args[0];
            if (args.length > 1) {
                anoCatalogo = args[1];
            }
        }
        String urlBase = "https://www.dac.unicamp.br/sistemas/catalogos/grad/catalogo"
                + anoCatalogo + "/curriculoPleno/cp"
                + curso + ".html";
        
        ExtraiPreReq extraiprereq = new ExtraiPreReq(urlBase);
        
        extraiprereq.exprereq(urlBase);
        extraiprereq.listaTudo(System.out);
        System.out.println(urlBase);
    }
}
