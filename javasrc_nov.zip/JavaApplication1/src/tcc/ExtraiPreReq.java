package tcc;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import static java.util.Arrays.equals;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ExtraiPreReq {
       String url;
       List<Materia> lista;
        
       public ExtraiPreReq(String url) {
        this.url = url;
        lista = new ArrayList<>();
    }

    public void exprereq(String url) {
        Document document;
        String disciplina;
        String req;
        String ementa;
        try {
            document = Jsoup.connect(url).get();

            Elements paragraphs = document.select("div.ancora");
            Elements just = document.select("div.justificado");
            Elements disciplinas = document.select("p");

            Element firstParagraph = paragraphs.first();
            Element lastParagraph = paragraphs.last();
            Element p = firstParagraph;

            Element firstjust = just.first();
            Element lastjust = just.last();
            Element j = firstjust;

            Element firstdisc = disciplinas.first();
            Element lastdisc = disciplinas.last();
            Element d = firstdisc;

            int w = 0;
            int i = 1;
            int z = 0;

            //System.out.println("*  " + p.text() + "\n");
            while (p != lastParagraph && j != lastjust && d != lastdisc) {

                p = paragraphs.get(i);
                j = just.get(z);
                d = disciplinas.get(w);
                String substring = d.text().substring(74, d.text().length());
                if (substring.equals("Pré-Req.: Não há")) {
                    i++;
                    z++;
                    w = w + 3;
                } else {
                    //Printa disciplina, pré requisitos e ementa
                    disciplina = p.text();
                    req = d.text();
                    ementa = j.text();
                    //System.out.println("*  " + p.text());
                    //System.out.println("*  " + d.text().substring(74, d.text().length()));
                    //System.out.println("*  " + j.text() + "\n");
                    Materia m = new Materia(disciplina, req, ementa);
                m.setUrl(document.attr("abs:href"));
                lista.add(m);
                    
                    i++;
                    z++;
                    w = w + 3;
                }
            }
            System.out.println("--------------------------------------------------------------");
        } catch (IOException e) {
            // TODO Auto-generated catch block

        }
        


    }
            public void listaTudo(PrintStream out) {
        for (Materia m : lista) {
            out.println(m.toString());
        }
    }
}


